# Roblox Companion Pro

แอป Android สำหรับจัดการลิงก์เกม Roblox, รายการโปรด, ตัวจับเวลา, คู่มือ และคลังโค้ด Luau สำหรับ Roblox Studio

## สถานะการตรวจสอบ
- โปรเจกต์ Kotlin/Jetpack Compose และ workflow สำหรับ build ถูกจัดเตรียมแล้ว
- ในสภาพแวดล้อมที่สร้างโปรเจกต์นี้ไม่มี Android SDK และไม่มี Gradle ติดตั้งไว้ จึงยังไม่ได้ยืนยันผล compile หรือรันบนอุปกรณ์จริง
- GitHub Actions จะ build `assembleDebug` และอัปโหลด APK เป็น Artifact เมื่อ workflow สำเร็จ
- APK ที่สร้างจาก workflow เป็น debug-signed สำหรับทดสอบ ไม่ใช่ release signing สำหรับเผยแพร่ใน Store

## Build ผ่านแท็บเล็ต Android
1. สร้าง repository ใหม่บน GitHub และอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (ยกเว้น APK ที่อัปโหลดแยก)
2. เปิดแท็บ **Actions** ใน repository และเลือก **Build Android APK**
3. กด **Run workflow** แล้วรอให้ job สำเร็จ
4. เปิด run ที่สำเร็จ เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Roblox-Companion-Pro-debug-apk`
5. แตก ZIP ของ Artifact จะได้ `app-debug.apk` (Artifact ZIP ไม่ใช่ APK โดยตรง)
6. เปิดไฟล์ APK บนแท็บเล็ตเพื่อเริ่มติดตั้ง หาก Android ขออนุญาตติดตั้งจากแหล่งนี้ ให้เปิดเฉพาะสำหรับแอปที่ใช้ดาวน์โหลด แล้วปิดกลับหลังติดตั้ง

## Build ในเครื่องที่มี Android SDK
ต้องมี JDK 17, Android SDK Platform 35, Build Tools 35.0.0 และ Gradle 8.9:
```bash
gradle --no-daemon assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## สิทธิ์ Android
ไม่มีการขอ permission runtime เพิ่มเติม, ไม่มี overlay permission, ไม่มี network permission และไม่มีการเข้าถึงข้อมูลบัญชี Roblox โดยตรง การนำเข้า/ส่งออกใช้ Android Storage Access Framework ซึ่งให้ผู้ใช้เลือกไฟล์เอง

## ขอบเขต
- เปิด Roblox โดยตรวจสอบ package `com.roblox.client` และเปิด URL Roblox ผ่าน Android Intent
- บันทึกเกม/รายการโปรด/สคริปต์ใน SharedPreferences ภายในเครื่อง
- ค้นหาเกม, แก้ไข, ลบ, นำเข้า/ส่งออก JSON และนำเข้า/ส่งออกโค้ด
- โค้ด Luau เป็นไฟล์ข้อความสำหรับ Roblox Studio ไม่ได้รันใน Roblox Client
- ไม่มี FPS overlay เพราะไม่มีแหล่งข้อมูล FPS ของ Roblox Client ที่เชื่อถือได้และได้รับอนุญาต
- เมนูลอยข้ามแอปไม่ได้รวมไว้ เพื่อลดสิทธิ์ที่ต้องใช้; มีแผงเครื่องมือภายในแอปแทน
- ปุ่มจับเวลาบนหน้าจอนี้เป็นนาฬิกาจับเวลาแบบกดเริ่ม/หยุด/รีเซ็ต; เป้าหมายนาทีเป็นข้อมูลอ้างอิง ไม่ใช่การแจ้งเตือนเบื้องหลัง

## ความเป็นส่วนตัว
ข้อมูลเกมและสคริปต์อยู่ในพื้นที่ข้อมูลของแอปบนอุปกรณ์ ไม่มี analytics หรือการส่งข้อมูลไปยังเซิร์ฟเวอร์ในโค้ดนี้
