package com.companion.robloxpro

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Purple = Color(0xFFB69CFF)
private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF1D1D25)
private val Muted = Color(0xFFB8B5C5)

data class GameItem(val id: Long, val name: String, val url: String, val category: String, val favorite: Boolean = false, val lastOpened: Long = 0)
data class ScriptItem(val name: String, val category: String, val code: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,16,20)
        window.navigationBarColor = android.graphics.Color.rgb(16,16,20)
        setContent { CompanionApp() }
    }
}

@Composable
fun CompanionApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("companion_data", 0) }
    var page by remember { mutableStateOf("Home") }
    var games by remember { mutableStateOf(loadGames(prefs.getString("games", "[]") ?: "[]")) }
    var scripts by remember { mutableStateOf(loadScripts(prefs.getString("scripts", "[]") ?: "[]")) }
    var fontScale by remember { mutableFloatStateOf(prefs.getFloat("fontScale", 1f)) }
    var autosave by remember { mutableStateOf(prefs.getBoolean("autosave", true)) }
    var search by remember { mutableStateOf("") }
    var gameName by remember { mutableStateOf("") }
    var gameUrl by remember { mutableStateOf("") }
    var gameCategory by remember { mutableStateOf("ทั่วไป") }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf("") }
    var scriptName by remember { mutableStateOf("") }
    var scriptCategory by remember { mutableStateOf("ตัวอย่าง") }
    var scriptCode by remember { mutableStateOf("-- Luau sample for Roblox Studio\nprint(\"Hello from Roblox Studio!\")") }
    var editingScript by remember { mutableStateOf<String?>(null) }
    var targetMinutes by remember { mutableStateOf("30") }
    var elapsed by remember { mutableLongStateOf(0L) }
    var stopwatchRunning by remember { mutableStateOf(false) }
    var stopwatchStart by remember { mutableLongStateOf(0L) }

    fun persistGames() { prefs.edit().putString("games", saveGames(games)).apply() }
    fun persistScripts() { prefs.edit().putString("scripts", saveScripts(scripts)).apply() }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(saveGames(games).toByteArray()) }
                message = "ส่งออกรายการเกมแล้ว"
            }.onFailure { message = "ส่งออกไม่สำเร็จ: ${it.localizedMessage}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "[]"
                games = loadGames(raw)
                persistGames()
                message = "นำเข้ารายการเกม ${games.size} รายการแล้ว"
            }.onFailure { message = "ไฟล์ไม่ถูกต้องหรืออ่านไม่ได้" }
        }
    }
    val exportScriptLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(scriptCode.toByteArray()) }
            message = "ส่งออกไฟล์ Luau แล้ว"
        }.onFailure { message = "ส่งออกไฟล์ไม่สำเร็จ" }
    }
    val importScriptLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            scriptCode = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            scriptName = Uri.decode(uri.lastPathSegment ?: "Imported.luau").substringAfterLast('/')
            message = "เปิดไฟล์โค้ดแล้ว"
        }.onFailure { message = "เปิดไฟล์ไม่ได้" }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Library", "Tools", "Scripts", "Settings").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Text(when(item) {"Home"->"⌂";"Library"->"▤";"Tools"->"◷";"Scripts"->"{}";else->"⚙"}) }, label = { Text(item, fontSize = (10 * fontScale).sp) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(18.dp))
                Text("ROBLOX COMPANION PRO", fontSize = (20 * fontScale).sp, fontWeight = FontWeight.Black, color = Purple)
                Text("เครื่องมือเสริมสำหรับผู้เล่น • เก็บข้อมูลไว้ในเครื่อง", color = Muted, fontSize = (12 * fontScale).sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    "Home" -> {
                        CardBox {
                            Text("ยินดีต้อนรับ", fontSize = (22 * fontScale).sp, fontWeight = FontWeight.Bold)
                            Text("รวมเกมโปรด คู่มือ ตัวจับเวลา และคลังโค้ด Luau ไว้ในที่เดียว", color = Muted)
                            Button(onClick = { openRoblox(context) { message = it } }, modifier = Modifier.fillMaxWidth()) { Text("เปิด Roblox") }
                            OutlinedButton(onClick = { page = "Library" }, modifier = Modifier.fillMaxWidth()) { Text("ไปยังคลังเกม") }
                        }
                        Spacer(Modifier.height(12.dp))
                        SectionTitle("เกมโปรด")
                        val favorites = games.filter { it.favorite }
                        if (favorites.isEmpty()) EmptyHint("ยังไม่มีเกมโปรด — เพิ่มลิงก์ในคลังเกม")
                        favorites.take(4).forEach { GameRow(it, { openGame(context, it) { message = it } }, { games = games.map { g -> if(g.id==it.id) g.copy(favorite=!g.favorite) else g }; persistGames() }, {}, showManage = false) }
                        SectionTitle("เปิดล่าสุด")
                        games.filter { it.lastOpened > 0 }.sortedByDescending { it.lastOpened }.take(3).forEach { Text("• ${it.name}", color = Color.White) }
                        if (message.isNotBlank()) Text(message, color = Purple)
                    }
                    "Library" -> {
                        SectionTitle("คลังเกม")
                        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("ค้นหาชื่อเกม / หมวดหมู่ / URL") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = gameName, onValueChange = { gameName = it }, label = { Text("ชื่อเกม") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = gameUrl, onValueChange = { gameUrl = it }, label = { Text("Roblox URL") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = gameCategory, onValueChange = { gameCategory = it }, label = { Text("หมวดหมู่") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val normalized = gameUrl.trim()
                                if (gameName.isBlank() || !validRobloxUrl(normalized)) message = "กรอกชื่อเกมและ URL Roblox ที่ถูกต้อง (roblox.com หรือ www.roblox.com)"
                                else {
                                    val id = editingId
                                    games = if (id == null) games + GameItem(System.currentTimeMillis(), gameName.trim(), normalized, gameCategory.trim().ifBlank { "ทั่วไป" })
                                    else games.map { if(it.id == id) it.copy(name=gameName.trim(), url=normalized, category=gameCategory.trim().ifBlank { "ทั่วไป" }) else it }
                                    persistGames(); gameName=""; gameUrl=""; editingId=null; message="บันทึกเกมแล้ว"
                                }
                            }, modifier = Modifier.weight(1f)) { Text(if(editingId == null) "เพิ่มเกม" else "บันทึกแก้ไข") }
                            OutlinedButton(onClick = { exportLauncher.launch("roblox-games.json") }) { Text("ส่งออก") }
                        }
                        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.fillMaxWidth()) { Text("นำเข้า JSON") }
                        Spacer(Modifier.height(12.dp))
                        val filtered = games.filter { "${it.name} ${it.category} ${it.url}".contains(search, true) }
                        Text("${filtered.size} เกม", color = Muted)
                        filtered.forEach { game ->
                            GameRow(game, { openGame(context, game) { message = it }; games = games.map { if(it.id==game.id) it.copy(lastOpened=System.currentTimeMillis()) else it }; persistGames() },
                                { games = games.map { if(it.id==game.id) it.copy(favorite=!it.favorite) else it }; persistGames() },
                                {
                                    gameName=game.name; gameUrl=game.url; gameCategory=game.category; editingId=game.id
                                },
                                onDelete = { games = games.filterNot { it.id == game.id }; persistGames(); message="ลบเกมแล้ว" })
                        }
                        if (message.isNotBlank()) Text(message, color = Purple)
                    }
                    "Tools" -> {
                        SectionTitle("Gaming Tools")
                        CardBox {
                            Text("ตัวจับเวลาเล่นเกม", fontWeight = FontWeight.Bold, fontSize = (18 * fontScale).sp)
                            OutlinedTextField(value = targetMinutes, onValueChange = { targetMinutes = it.filter(Char::isDigit).take(4) }, label = { Text("เป้าหมาย (นาที)") }, modifier = Modifier.fillMaxWidth())
                            Text("เป้าหมาย: ${targetMinutes.ifBlank { "0" }} นาที")
                            Text("ใช้ตัวจับเวลา Android ภายในแอป ไม่ตรวจจับเวลาใน Roblox โดยอัตโนมัติ", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        CardBox {
                            Text("นาฬิกาจับเวลา", fontWeight = FontWeight.Bold, fontSize = (18 * fontScale).sp)
                            Text(formatElapsed(if(stopwatchRunning) elapsed + (System.currentTimeMillis()-stopwatchStart) else elapsed), fontSize = 28.sp, color = Purple, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { if(stopwatchRunning) { elapsed += System.currentTimeMillis()-stopwatchStart; stopwatchRunning=false } else { stopwatchStart=System.currentTimeMillis(); stopwatchRunning=true } }) { Text(if(stopwatchRunning) "หยุด" else "เริ่ม") }
                                OutlinedButton(onClick = { elapsed=0; stopwatchRunning=false }) { Text("รีเซ็ต") }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        CardBox {
                            Text("คู่มือปรับประสบการณ์", fontWeight = FontWeight.Bold)
                            Text("• ปรับ Graphics Mode และ Graphics Quality ในเมนู Settings ของ Roblox หากเกมกระตุก\\n• ปิดแอปพื้นหลังที่ไม่จำเป็น\\n• ใช้ Wi‑Fi ที่เสถียรและตรวจสอบอุณหภูมิแท็บเล็ต\\n• ปรับความไวการควบคุมในเกมที่มีตัวเลือกดังกล่าว", color = Muted)
                            OutlinedButton(onClick = { runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS)) }.onFailure { message="เปิดการตั้งค่าหน้าจอไม่ได้" } }) { Text("เปิดการตั้งค่าหน้าจอ Android") }
                        }
                        Text("FPS: ไม่แสดง — แอปภายนอกนี้ไม่มีแหล่งข้อมูล FPS ของ Roblox Client ที่เชื่อถือได้และได้รับอนุญาต", color = Muted, fontSize = 12.sp)
                        if(message.isNotBlank()) Text(message, color = Purple)
                    }
                    "Scripts" -> {
                        SectionTitle("Script Library · Luau")
                        Text("โค้ดนี้มีไว้สำหรับเรียนรู้และใช้ใน Roblox Studio เท่านั้น ไม่ได้รันหรือฉีดเข้า Roblox Client", color = Muted)
                        OutlinedTextField(value = scriptName, onValueChange = { scriptName=it }, label = { Text("ชื่อไฟล์ / สคริปต์") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = scriptCategory, onValueChange = { scriptCategory=it }, label = { Text("หมวดหมู่") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = scriptCode, onValueChange = { scriptCode=it }, label = { Text("โค้ด Luau") }, modifier = Modifier.fillMaxWidth().height(240.dp), minLines = 8)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if(scriptName.isBlank()) message="ใส่ชื่อสคริปต์ก่อนบันทึก"
                                else {
                                    val item=ScriptItem(scriptName.trim(), scriptCategory.trim().ifBlank { "ทั่วไป" }, scriptCode)
                                    scripts = if(editingScript==null) scripts + item else scripts.map { if(it.name==editingScript) item else it }
                                    persistScripts(); editingScript=null; message="บันทึกสคริปต์แล้ว"
                                }
                            }, modifier = Modifier.weight(1f)) { Text("บันทึก") }
                            OutlinedButton(onClick = { exportScriptLauncher.launch(scriptName.ifBlank { "script.luau" }) }) { Text("ส่งออก") }
                        }
                        OutlinedButton(onClick = { importScriptLauncher.launch(arrayOf("text/*", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) { Text("เปิดไฟล์ Luau / Lua") }
                        SectionTitle("สคริปต์ที่บันทึก")
                        scripts.forEach { script ->
                            CardBox {
                                Text(script.name, fontWeight = FontWeight.Bold)
                                Text(script.category, color = Muted)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { scriptName=script.name; scriptCategory=script.category; scriptCode=script.code; editingScript=script.name }) { Text("แก้ไข") }
                                    TextButton(onClick = { GenCopy(context, script.code); message="คัดลอกโค้ดแล้ว" }) { Text("คัดลอก") }
                                    TextButton(onClick = { scripts=scripts.filterNot { it.name==script.name }; persistScripts() }) { Text("ลบ") }
                                }
                            }
                        }
                        if(message.isNotBlank()) Text(message, color = Purple)
                    }
                    else -> {
                        SectionTitle("Settings")
                        CardBox {
                            Text("ขนาดตัวอักษร", fontWeight = FontWeight.Bold)
                            Text("ปรับขนาด UI: ${(fontScale*100).toInt()}%")
                            Slider(value = fontScale, onValueChange = { fontScale=it; prefs.edit().putFloat("fontScale",it).apply() }, valueRange = 0.85f..1.35f)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("บันทึกอัตโนมัติ")
                                Spacer(Modifier.weight(1f))
                                Switch(checked = autosave, onCheckedChange = { autosave=it; prefs.edit().putBoolean("autosave",it).apply() })
                            }
                            Text("ข้อมูลเกมและสคริปต์จะบันทึกเมื่อกดปุ่มบันทึก/แก้ไขทุกครั้ง", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        CardBox {
                            Text("จัดการข้อมูลในเครื่อง", fontWeight = FontWeight.Bold)
                            Text("เกม ${games.size} รายการ • สคริปต์ ${scripts.size} รายการ")
                            OutlinedButton(onClick = { games= emptyList(); scripts= emptyList(); persistGames(); persistScripts(); message="ล้างข้อมูลเกมและสคริปต์แล้ว" }, modifier = Modifier.fillMaxWidth()) { Text("ลบข้อมูลเกมและสคริปต์ทั้งหมด") }
                        }
                        Spacer(Modifier.height(12.dp))
                        CardBox {
                            Text("เกี่ยวกับแอป", fontWeight = FontWeight.Bold)
                            Text("Roblox Companion Pro 1.0.0")
                            Text("นโยบายความเป็นส่วนตัว: ข้อมูลเกม รายการโปรด และสคริปต์จัดเก็บภายในเครื่อง แอปนี้ไม่ส่งข้อมูลไปยังเซิร์ฟเวอร์ ไม่มีระบบเข้าสู่ระบบและไม่ขอรหัสผ่าน Roblox", color = Muted)
                            Text("แอปนี้ไม่ใช่ผลิตภัณฑ์ทางการของ Roblox Corporation", color = Muted)
                        }
                        if(message.isNotBlank()) Text(message, color = Purple)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable private fun SectionTitle(text: String) { Spacer(Modifier.height(8.dp)); Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White); Spacer(Modifier.height(8.dp)) }
@Composable private fun EmptyHint(text: String) { Text(text, color = Muted, modifier = Modifier.padding(vertical=8.dp)) }
@Composable private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}
@Composable private fun GameRow(game: GameItem, onOpen: () -> Unit, onFavorite: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit = {}, showManage: Boolean = true) {
    CardBox {
        Text(game.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text("${game.category} • ${game.url}", color = Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Button(onClick = onOpen) { Text("เปิด") }
            TextButton(onClick = onFavorite) { Text(if(game.favorite) "★ โปรด" else "☆ โปรด") }
            if (showManage) {
                TextButton(onClick = onEdit) { Text("แก้ไข") }
                TextButton(onClick = onDelete) { Text("ลบ") }
            }
        }
    }
    Spacer(Modifier.height(8.dp))
}
private fun validRobloxUrl(value: String): Boolean = runCatching {
    val uri=Uri.parse(value)
    uri.scheme in listOf("https","http") && (uri.host == "roblox.com" || uri.host?.endsWith(".roblox.com") == true)
}.getOrDefault(false)
private fun openRoblox(context: android.content.Context, report: (String)->Unit) {
    val intent=context.packageManager.getLaunchIntentForPackage("com.roblox.client")
    if(intent == null) report("ไม่พบแอป Roblox ทางการที่ติดตั้งอยู่ กรุณาติดตั้งจาก Google Play")
    else runCatching { context.startActivity(intent); report("กำลังเปิด Roblox") }.onFailure { report("เปิด Roblox ไม่สำเร็จ") }
}
private fun openGame(context: android.content.Context, game: GameItem, report: (String)->Unit) {
    if(!validRobloxUrl(game.url)) { report("ลิงก์ไม่ใช่โดเมน Roblox ที่รองรับ"); return }
    runCatching {
        val intent=Intent(Intent.ACTION_VIEW, Uri.parse(game.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        report("กำลังเปิด ${game.name}")
    }.onFailure {
        if(it is ActivityNotFoundException) report("ไม่พบแอปที่เปิดลิงก์นี้ได้ กรุณาติดตั้ง Roblox หรือเปิดผ่านเบราว์เซอร์")
        else report("เปิดลิงก์ไม่สำเร็จ: ${it.localizedMessage}")
    }
}
private fun loadGames(raw: String): List<GameItem> = runCatching {
    val arr=JSONArray(raw); (0 until arr.length()).map { i -> arr.getJSONObject(i).let { GameItem(it.optLong("id",System.currentTimeMillis()+i),it.optString("name"),it.optString("url"),it.optString("category","ทั่วไป"),it.optBoolean("favorite"),it.optLong("lastOpened")) } }
}.getOrDefault(emptyList())
private fun saveGames(games: List<GameItem>): String = JSONArray().apply {
    games.forEach { g -> put(JSONObject().put("id",g.id).put("name",g.name).put("url",g.url).put("category",g.category).put("favorite",g.favorite).put("lastOpened",g.lastOpened)) }
}.toString()
private fun loadScripts(raw: String): List<ScriptItem> = runCatching {
    val arr=JSONArray(raw); (0 until arr.length()).map { i -> arr.getJSONObject(i).let { ScriptItem(it.optString("name"),it.optString("category","ทั่วไป"),it.optString("code")) } }
}.getOrDefault(emptyList())
private fun saveScripts(scripts: List<ScriptItem>): String = JSONArray().apply {
    scripts.forEach { s -> put(JSONObject().put("name",s.name).put("category",s.category).put("code",s.code)) }
}.toString()
private fun formatElapsed(ms: Long): String {
    val total=ms/1000; return "%02d:%02d:%02d".format(total/3600,(total/60)%60,total%60)
}
private fun GenCopy(context: android.content.Context, text: String) {
    val clipboard=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Luau code",text))
}
